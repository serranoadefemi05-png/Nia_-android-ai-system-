# NIA Architecture

## High-Level

```
┌─────────────────────────────────────────────────┐
│                  Android App                    │
│  VoiceOrchestrator → NiaViewModel → ActionReg   │
│  SpeechRecognizer / TTS / ConfirmationDialog     │
└────────────────────┬────────────────────────────┘
                     │ HTTPS / WebSocket
┌────────────────────▼────────────────────────────┐
│              NIA Backend (FastAPI)               │
│                                                  │
│  /api/v1/auth        JWT auth                   │
│  /api/v1/assistant   AI orchestration           │
│  /api/v1/tasks       Task history               │
│  /api/v1/memory      User memory                │
│  /api/v1/tools       Tool registry              │
│  /api/v1/web         Web agent                  │
│  /api/v1/health      Health check               │
│                                                  │
│  Orchestrator pipeline:                          │
│  Intent → Plan → Permission → Confirm →          │
│  Execute → Verify → Memory → Response            │
└────────────────────┬────────────────────────────┘
                     │ (future v0.2+)
┌────────────────────▼────────────────────────────┐
│               Arc Ecosystem                      │
│  Agent Identity · USDC Payments · Attestations   │
│  Agent Marketplace · Spending Policies           │
└─────────────────────────────────────────────────┘
```

## Orchestrator Pipeline

```
USER VOICE INPUT
      │
      ▼
Speech-to-Text (Android SpeechRecognizer)
      │
      ▼
Input Sanitization (prompt injection defense)
      │
      ▼
Intent Parser → (intent, tool_id)
      │
      ▼
Permission Check → missing? → request permissions
      │
      ▼
Confirmation Check
  GREEN → auto-proceed
  YELLOW → show confirmation dialog, wait for tap
  RED → require typed "confirm", explicit approval
      │
      ▼
Parameter Extraction
      │
      ▼
Tool Execution (via registered AndroidAction / backend handler)
      │
      ▼
Verification
      │
      ▼
Memory Update (task history, user prefs)
      │
      ▼
Response Generation
      │
      ▼
Text-to-Speech → user hears response
```

## Confirmation Levels

| Level | Color | Examples | Requires |
|---|---|---|---|
| GREEN | Auto | screenshot, web search, reminder, open app, file search | Nothing |
| YELLOW | Confirm | send message, edit file, submit form | Tap "Confirm" |
| RED | Danger | make payment, delete data, change security settings | Type "confirm" |

## Tool Registry

Every capability is registered with:
- Unique ID
- Human-readable description
- Input/output schema
- Required Android permissions
- Risk level (LOW / MEDIUM / HIGH / CRITICAL)
- Confirmation level (GREEN / YELLOW / RED)
- Execute handler (optional — some dispatch to the Android client)
- Verify handler

## Memory Architecture

```
MemoryService
├── MemoryRepository   (in-memory v0.1; swap for DB in v0.2)
└── MemoryPolicy       (blocks sensitive keys; enforces size limits)

Memory types:
  preference           User preferences
  fact                 Explicitly saved facts
  task_history         Completed task records
  conversation_summary Session summaries
```

## Security Layers

1. JWT authentication (access + refresh tokens, rotation, revocation)
2. bcrypt password hashing
3. Prompt injection detection at input sanitization layer
4. SSRF protection on all server-side web fetches
5. Tool-level permission checks (Android permissions)
6. Tool-level confirmation checks (GREEN/YELLOW/RED)
7. API-layer confirmation enforcement (cannot bypass via direct API call)
8. Android Keystore for local credential storage
9. EncryptedSharedPreferences for all local data
10. Rate limiting (per-IP, configurable)
11. Input length limits
12. Memory policy (blocks sensitive key storage)

## Android Action Registry

```kotlin
interface AndroidAction {
  val id: String
  val description: String
  val requiredPermissions: List<String>
  val riskLevel: RiskLevel
  val confirmationLevel: ConfirmationLevel
  val parameters: List<ActionParameter>
  suspend fun execute(params: Map<String, Any?>): ActionResult
  suspend fun verify(result: ActionResult): Boolean
}
```

Built-in actions (v0.1):
- `take_screenshot` — MediaProjection
- `search_local_files` — Storage Access Framework
- `create_reminder` — AlarmClock Intent
- `open_app` — PackageManager launch intent
- `web_search` — Delegates to backend

## Arc Integration Boundary (v0.2+)

```
ArcServiceInterface
├── getAgentIdentity()
├── getSpendingPolicy()
├── requestPayment()       ← always requires user confirmation
├── getUsdcBalance()
├── recordTaskAttestation()
└── discoverAgentServices()
```

Arc is used ONLY where blockchain provides a real product advantage:
- Verifiable task attestations
- USDC payments with user-defined spending policies
- Agent identity and marketplace

Arc is NOT used for ordinary Android functionality.
